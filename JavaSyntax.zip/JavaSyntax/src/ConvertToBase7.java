import java.util.Scanner;

/**
 * Created by dell on 21.3.2016 г..
 */
public class ConvertToBase7 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        Integer num=input.nextInt();
        System.out.println(Integer.toString(num,7));
    }
}
