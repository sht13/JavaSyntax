import java.util.Scanner;

/**
 * Created by dell on 21.3.2016 г..
 */
public class ConvertFromBase7
{
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        Integer num=input.nextInt();
        Integer a=Integer.valueOf(String.valueOf(num),7);
        System.out.println(a);
    }
}
