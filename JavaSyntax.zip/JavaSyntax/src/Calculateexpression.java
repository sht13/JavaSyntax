import java.util.Locale;
import java.util.Scanner;

/**
 * Created by dell on 21.3.2016 г..
 */
public class Calculateexpression {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        input.useLocale(Locale.ENGLISH);
        double a=input.nextDouble();
        double b=input.nextDouble();
        double c=input.nextDouble();
        double secondPow1=(a+b+c)/(Math.sqrt(c));
        double firstPow1=(Math.pow(a,2)+Math.pow(b,2))/(Math.pow(a,2)-Math.pow(b,2));
        double firstFormula=Math.pow(firstPow1,secondPow1);
        double secondPow2=a-b;
        double firstPow2=Math.pow(a,2)+Math.pow(b,2)-Math.pow(c,3);
        double secondFormula=Math.pow(firstPow2,secondPow2);
        double diff=((a+b+c)/3)-((firstFormula+secondFormula)/2);
        System.out.printf("F1 result: %1$.2f; F2 result: %2$.2f; Diff: %3$.2f",firstFormula,secondFormula,Math.abs(diff));

            }
}
