
import java.util.Scanner;


/**
 * Created by dell on 9.3.2016 г..
 */

public class GetFirstOddEvenElements {
    private static void evenNum(int[] arr,int x) {

            for (int i = 0; i < arr.length; i++) {
                if (arr[i] % 2 == 0) {
                    if(x>0){
                    System.out.print(arr[i] + " ");
                    x--;
                    }

                }
            }
        }

    private static void oddNum(int[] arr,int x) {

        for (int i = 0; i < arr.length; i++) {


            if (arr[i] % 2 == 1) {
                if(x>0){
                    System.out.print(arr[i] + " ");
                    x--;
                }

            }
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] num = input.nextLine().split(" ");
        int[] n = new int[num.length];
        for (int i = 0; i < num.length; i++) {

            n[i] = Integer.parseInt(num[i]);
        }
        String[] enter = input.nextLine().split(" ");
        int x = Integer.parseInt(enter[1]);
        String expectedN = enter[2];
        String even = "even";
        String odd = "odd";
        if (expectedN.equals(even)) evenNum(n,x);
else if (expectedN.equals(odd)) oddNum(n,x);

        }

    }


