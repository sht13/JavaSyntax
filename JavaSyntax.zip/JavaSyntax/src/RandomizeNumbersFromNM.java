import java.util.Random;
import java.util.Scanner;

/**
 * Created by dell on 5.3.2016 г..
 */
public class RandomizeNumbersFromNM {
    public static void main(String[] args) {

        Scanner input=new Scanner(System.in);
        int n=input.nextInt();
        int m=input.nextInt();
        int min = Math.min(n, m);
        int max = Math.max(n, m);
        Random rand = new Random();

        for(int i=min;i<=max;i++){
        int  num = rand.nextInt((max - min) + 1) + min;
        System.out.print(num+" ");
        }
    }
}
