import java.util.Scanner;

/**
 * Created by dell on 29.2.2016 г..
 */
public class OddEvenPairs {
    public static void main(String[] args) {

        Scanner input=new Scanner(System.in);
        String[] line=input.nextLine().split(" ");

        if(line.length%2==1){
            System.out.println("Invalid length");
        }
        else if(line.length%2==0) {
            int[] num = new int[line.length];

            for (int i = 0; i < line.length; i++) {
                num[i] = Integer.parseInt(line[i]);
            }
        for(int i=0;i<num.length-1;i+=2){
            if(num[i]%2==1 || num[i+1]==0) {
                System.out.println(num[i]+", "+num[i+1]+" -> different");
            }
            else if (num[i]%2==0 || num[i+1]==1){
                System.out.println(num[i]+", "+num[i+1]+" -> different");
            }
            else if(num[i]%2==0 && num[i]%2==0){
                System.out.println(num[i]+", "+num[i+1]+" -> both are even");
            }
            else if(num[i]%2==1 && num[i+1]%2==1){
                System.out.println(num[i]+", "+num[i+1]+" -> both are odd");

            }
        }
        }

    }
}
