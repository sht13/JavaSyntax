import java.util.Scanner;

/**
 * Created by dell on 29.2.2016 г..
 */
public class RectangleArea {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int firstN=input.nextInt();
        int secondN=input.nextInt();
        System.out.println(firstN*secondN);
    }
}
