import java.util.Scanner;

/**
 * Created by dell on 9.3.2016 г..
 */
public class CharacterMultiplier {
    private  static int SumEqual(String first,String second) {
        int sum = 0;
        int count=0;
        String wichString=first.length()-second.length()>0?first:second;
        int max=Math.max(first.length(),second.length());
        int min=Math.min(first.length(),second.length());

        for (int i = 0; i <min ; i++) {
            char c1 = first.charAt(i);
            char c2 = second.charAt(i);
            int multyply = (int) c1 * (int) c2;
            sum += multyply;
            count++;
        }
for(int i=count;i<max;i++){
    sum+=wichString.charAt(i);

}
        return sum;
}



    public static void main(String[] args) {

        Scanner input=new Scanner(System.in);
        String[] enter=input.nextLine().split(" ");
String first=enter[0];
        String second=enter[1];
        int summa=SumEqual(first,second);
        System.out.println(summa);
            }
}
