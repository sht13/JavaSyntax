import java.util.Scanner;

/**
 * Created by dell on 21.3.2016 г..
 */
public class TriangleArea {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        Integer aX=input.nextInt();
        Integer aY=input.nextInt();
        input.nextLine();
        Integer bX=input.nextInt();
        Integer bY=input.nextInt();
        input.nextLine();
        Integer cX=input.nextInt();
        Integer cY=input.nextInt();
        input.nextLine();
        Integer area=(((aX*(bY-cY))+(bX*(cY-aY))+(cX*(aY-bY)))/2);
        System.out.println(Math.abs(area));

    }
}
